
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/User/CLionProjects/laborator-2_4/domain.c" "CMakeFiles/laborator_2_4.dir/domain.c.o" "gcc" "CMakeFiles/laborator_2_4.dir/domain.c.o.d"
  "/mnt/c/Users/User/CLionProjects/laborator-2_4/main.c" "CMakeFiles/laborator_2_4.dir/main.c.o" "gcc" "CMakeFiles/laborator_2_4.dir/main.c.o.d"
  "/mnt/c/Users/User/CLionProjects/laborator-2_4/repo.c" "CMakeFiles/laborator_2_4.dir/repo.c.o" "gcc" "CMakeFiles/laborator_2_4.dir/repo.c.o.d"
  "/mnt/c/Users/User/CLionProjects/laborator-2_4/service.c" "CMakeFiles/laborator_2_4.dir/service.c.o" "gcc" "CMakeFiles/laborator_2_4.dir/service.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
