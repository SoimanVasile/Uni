# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for laborator_2_4.
