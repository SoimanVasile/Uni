file(REMOVE_RECURSE
  "CMakeFiles/laborator_2_4.dir/domain.c.o"
  "CMakeFiles/laborator_2_4.dir/domain.c.o.d"
  "CMakeFiles/laborator_2_4.dir/main.c.o"
  "CMakeFiles/laborator_2_4.dir/main.c.o.d"
  "CMakeFiles/laborator_2_4.dir/repo.c.o"
  "CMakeFiles/laborator_2_4.dir/repo.c.o.d"
  "CMakeFiles/laborator_2_4.dir/service.c.o"
  "CMakeFiles/laborator_2_4.dir/service.c.o.d"
  "laborator_2_4"
  "laborator_2_4.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/laborator_2_4.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
